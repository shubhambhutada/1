package com.cg.dw.dao;

import java.math.BigInteger;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.RollbackException;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.dw.exception.ErrorMessages;
import com.cg.dw.exception.IBSException;
import com.cg.dw.model.CaseIdBean;

@Repository
public class CaseIdDaoImpl implements CaseIdDao {
	//private static Logger logger = Logger.getLogger(CaseIdDaoImpl.class);
	@PersistenceContext
	private EntityManager entityManager;


	@Override
	public boolean verifyQueryId(String queryId) throws IBSException {
		boolean result = false;

		try {
			CaseIdBean d = entityManager.find(CaseIdBean.class, queryId);
			if (d != null)
				result = true;
		} catch (NoResultException e) {
			throw new IBSException("gf");
		}
		return result;
	}

	@Override
	public void setQueryStatus(String queryId, String newStatus, String remarks) throws IBSException {
		//logger.info("entered into setQueryStatus method of CaseIdDaoImpl class");
		try {
			CaseIdBean query = entityManager.find(CaseIdBean.class, queryId);
			if (query != null) {
				query.setStatusOfServiceRequest(newStatus);
				query.setBankAdminRemarks(remarks);

				entityManager.merge(query);

			}
		} catch (RollbackException e) {
			throw new IBSException("No such request");
		}

	}

	@Override
	public String getNewType(String queryId) throws IBSException {
		//logger.info("entered into getNewType method of CaseIdDaoImpl class");

		CaseIdBean caseId = entityManager.find(CaseIdBean.class, queryId);
		return caseId.getDefineServiceRequest();
	}

	@Override
	public void actionServiceRequest(CaseIdBean caseIdObj) throws IBSException {
		//logger.info("entered into actionServiceRequest method of CaseIdDaoImpl class");
		try {
			
			entityManager.persist(caseIdObj);

		} catch (RollbackException e) {
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);

		}

	}

	@Override
	public String getCustomerReferenceStatus(CaseIdBean caseIdObj, String customerReferenceId) throws IBSException {
		//logger.info("entered into getCustomerReferenceStatus method of CaseIdDaoImpl class");
		String status;
		try {
			TypedQuery<String> query = entityManager.createQuery(
					"Select d.statusOfServiceRequest from CaseIdBean d where customerReferenceId=:customerRef",
					String.class);
			query.setParameter("customerRef", customerReferenceId);
			status = query.getSingleResult();
		} catch (NoResultException e) {
			throw new IBSException(ErrorMessages.NO_CUSTREFERENCESTATUS);
		}
		return status;

	}

	@Override
	public BigInteger getNewUCI(String queryId) throws IBSException {
		//logger.info("entered into getNewUCI method of CaseIdDaoImpl class");
		BigInteger UCI = null;
		try {
			TypedQuery<BigInteger> query = entityManager.createQuery(
					"select a.UCI from CaseIdBean d INNER JOIN d.customerBeanObject a where d.caseIdTotal=:queryID",
					BigInteger.class);
			query.setParameter("queryID", queryId);

			UCI = query.getSingleResult();
		} catch (NoResultException e) {
			throw new IBSException(ErrorMessages.NO_UCI);
		}
		return UCI;
	}

	@Override
	public CaseIdBean getCaseObj(String queryId) throws IBSException {
		//logger.info("entered into getCaseObj method of CaseIdDaoImpl class");
		CaseIdBean obj = null;
		try {
			obj = entityManager.find(CaseIdBean.class, queryId);
		} catch (NullPointerException e) {
			throw new IBSException(ErrorMessages.NO_QUERIES);
		}
		return obj;
	}

	@Override
	public List<CaseIdBean> viewCreditMismatchQueries() throws IBSException {
		List<CaseIdBean> listOfQueries = null;
		try {
			TypedQuery<CaseIdBean> query = entityManager
					.createQuery(SqlQueries.SELECT_DATA_FROM_SERVICE_REQUEST_FOR_CREDIT_MISMATCH, CaseIdBean.class);

			listOfQueries = query.getResultList();
		} catch (NoResultException e) {
			throw new IBSException(ErrorMessages.NO_QUERIES);
		}
		return listOfQueries;
	}

	@Override
	public List<CaseIdBean> viewDebitMismatchQueries() throws IBSException {
		List<CaseIdBean> listOfQueries = null;
		try {
			TypedQuery<CaseIdBean> query = entityManager
					.createQuery(SqlQueries.SELECT_DATA_FROM_SERVICE_REQUEST_FOR_DEBIT_MISMATCH, CaseIdBean.class);

			listOfQueries = query.getResultList();
		} catch (NoResultException e) {
			throw new IBSException(ErrorMessages.NO_QUERIES);
		}
		return listOfQueries;
	}

	@Override
	public List<CaseIdBean> viewCreditUpgradeQueries() throws IBSException {
		List<CaseIdBean> listOfQueries = null;
		try {
			TypedQuery<CaseIdBean> query = entityManager
					.createQuery(SqlQueries.SELECT_DATA_FROM_SERVICE_REQUEST_FOR_CREDIT_UPGRADE, CaseIdBean.class);

			listOfQueries = query.getResultList();
		} catch (NoResultException e) {
			throw new IBSException(ErrorMessages.NO_QUERIES);
		}
		return listOfQueries;
	}

	@Override
	public List<CaseIdBean> viewDebitUpgradeQueries() throws IBSException {
		List<CaseIdBean> listOfQueries = null;
		try {
			TypedQuery<CaseIdBean> query = entityManager
					.createQuery(SqlQueries.SELECT_DATA_FROM_SERVICE_REQUEST_FOR_DEBIT_UPGRADE, CaseIdBean.class);

			listOfQueries = query.getResultList();
		} catch (NoResultException e) {
			throw new IBSException(ErrorMessages.NO_QUERIES);
		}
		return listOfQueries;
	}

	@Override
	public List<CaseIdBean> viewNewCreditQueries() throws IBSException {
		List<CaseIdBean> listOfQueries = null;
		try {
			TypedQuery<CaseIdBean> query = entityManager
					.createQuery(SqlQueries.SELECT_DATA_FROM_SERVICE_REQUEST_FOR_NEW_CREDIT, CaseIdBean.class);

			listOfQueries = query.getResultList();
		} catch (NoResultException e) {
			throw new IBSException(ErrorMessages.NO_QUERIES);
		}
		return listOfQueries;
	}

	@Override
	public List<CaseIdBean> viewNewdebitQueries() throws IBSException {
		List<CaseIdBean> listOfQueries = null;
		try {
			TypedQuery<CaseIdBean> query = entityManager
					.createQuery(SqlQueries.SELECT_DATA_FROM_SERVICE_REQUEST_FOR_NEW_DEBIT, CaseIdBean.class);

			listOfQueries = query.getResultList();
		} catch (NoResultException e) {
			throw new IBSException(ErrorMessages.NO_QUERIES);
		}
		return listOfQueries;
	}

}
