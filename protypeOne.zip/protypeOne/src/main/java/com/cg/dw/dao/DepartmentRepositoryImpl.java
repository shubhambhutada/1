package com.cg.dw.dao;

import java.math.BigInteger;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.dw.model.DebitCardBean;
import com.cg.dw.model.Department;

@Repository
public class DepartmentRepositoryImpl implements DepartmentRepository{

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public Department add(Department dept) {
		entityManager.persist(dept);
		return dept;
	}

	@Override
	public Department save(Department dept) {
		entityManager.merge(dept);
		return dept;
	}

	@Override
	public Department findById(Long deptId) {
		return entityManager.find(Department.class, deptId);
	}

	@Override
	public List<Department> findAll() {
		Query deptQry = entityManager.createNamedQuery("findAllQry");		
		return deptQry.getResultList();
	}

	@Override
	public List<Department> findAllByName(String dName) {
		Query deptQry = entityManager.createNamedQuery("findAllByNameQry");
		deptQry.setParameter("dName", dName);
		return deptQry.getResultList();
	}

	@Override
	public boolean blockDebitCard(BigInteger debitCardNumber) {
		boolean result = false;
		DebitCardBean cardBean = null;

			cardBean = entityManager.find(DebitCardBean.class, debitCardNumber);
			cardBean.setCardStatus("Blocked");
			if(cardBean.getCardStatus().equals("Blocked")){
				result = true;
			}
			return result;
	}
	

}
