package com.cg.dw.dao;

import java.math.BigInteger;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.dw.exception.ErrorMessages;
import com.cg.dw.exception.IBSException;
import com.cg.dw.model.AccountBean;

@Repository
public class AccountDaoImpl implements AccountDao {
	@PersistenceContext
	private EntityManager entityManager;
	//private static final Logger LOGGER = Logger.getLogger(AccountDaoImpl.class);

	@Override
	public BigInteger getUci(BigInteger accountNumber) throws IBSException {
		//LOGGER.info("entered getUci in AccountDaoImpl");
		BigInteger acc=null;
try {
		TypedQuery<BigInteger> query = entityManager.createQuery(
				"select c.UCI from AccountBean d JOIN d.customerBeanObject c where d.accountNumber=:accountNum",
				BigInteger.class);
	query.setParameter("accountNum", accountNumber);
	
	
 acc=query.getSingleResult();}
catch (NoResultException e) {
	throw new IBSException(ErrorMessages.NO_UCI);
}

		return acc;

	}

	@Override
	public boolean verifyAccountNumber(BigInteger accountNumber) throws IBSException {
		//LOGGER.info("entered verifyAccountNumber in AccountDaoImpl");
		boolean result = false;

		AccountBean d = entityManager.find(AccountBean.class, accountNumber);

		if (d != null)
			result = true;

		return result;
	}

}
