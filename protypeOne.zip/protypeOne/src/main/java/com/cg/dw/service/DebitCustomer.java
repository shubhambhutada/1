package com.cg.dw.service;

import java.math.BigInteger;
import java.time.LocalDate;
import java.util.List;

import com.cg.dw.exception.IBSException;
import com.cg.dw.model.AccountBean;
import com.cg.dw.model.DebitCardBean;
import com.cg.dw.model.DebitCardTransaction;

public interface DebitCustomer {

	public List<DebitCardBean> viewAllDebitCards() throws IBSException;

	String requestDebitCardUpgrade(BigInteger debitCardNumber, String myChoice,String remarks) throws IBSException;

	void resetDebitPin(BigInteger debitCardNumber, String pin) throws IBSException;

	String getDebitcardType(BigInteger debitCardNumber) throws IBSException;
	String getDebitcardStatus(BigInteger debitCardNumber) throws IBSException;

	void requestDebitCardLost(BigInteger debitCardNumber) throws IBSException;

	String raiseDebitMismatchTicket(BigInteger transactionId, String remarks) throws IBSException;

	//public List<DebitCardTransaction> getDebitTransactions(int dys, BigInteger debitCardNumber) throws IBSException;

	public List<DebitCardBean> getUnblockedDebitCards() throws IBSException;

	public List<AccountBean> getAccountList() throws IBSException;

	public boolean checkDebitCardCount() throws IBSException;

	void deactivateDebitCard(BigInteger debitCardNumber) throws IBSException;

	//public void activateDebitCard(BigInteger debitCardNumber, String pin) throws IBSException;

	public List<DebitCardBean> getInactiveDebitCards() throws IBSException;

	String addToServiceRequestTable(String caseIdGenOne);

	public List<DebitCardTransaction> getDebitTransactions(LocalDate startDate1, LocalDate endDate1,
			BigInteger debitCardNumber) throws IBSException;

	public boolean getDebitTransactions(BigInteger debitCardNumber)throws IBSException;

	void activateDebitCard(BigInteger debitCardNumber) throws IBSException;

	String applyNewDebitCard(BigInteger accountNumber, String newCardType, String remarks) throws IBSException;

	DebitCardBean fetchDebitdetails(BigInteger debitCardNumber) throws IBSException;

	
}
