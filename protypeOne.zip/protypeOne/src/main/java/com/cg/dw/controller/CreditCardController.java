package com.cg.dw.controller;

import java.math.BigInteger;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.dw.exception.IBSException;
import com.cg.dw.model.CreditCardBean;
import com.cg.dw.model.CreditCardTransaction;
import com.cg.dw.model.DebitCardBean;
import com.cg.dw.model.DebitCardTransaction;
import com.cg.dw.service.CreditCustomer;
import com.cg.dw.service.CreditCustomerVerification;
import com.cg.dw.service.DebitCustomer;
import com.cg.dw.service.DebitCustomerVerification;

@Controller
@Scope("session")
public class CreditCardController {
	BigInteger cardNumber;
	BigInteger creditCard;
	@Autowired
	private CreditCustomer creditService;
	@Autowired
	private CreditCustomerVerification creditVerify;
	List<CreditCardTransaction> trans;
	CreditCardBean creditBean = new CreditCardBean();
	
	@RequestMapping(value = "/creditlist", method = RequestMethod.GET)
    public ModelAndView list() {
        List<CreditCardBean> creditCardBeans;
        try {
            creditCardBeans = creditService.viewAllCreditCards();
        } catch (IBSException e) {
            String message = e.getMessage();
            return new ModelAndView("errorPage", "errorMessage", message);
        }
        return new ModelAndView("listCreditCards", "output", creditCardBeans);
    }
	
	@RequestMapping("/cards")
	public ModelAndView showCardHome() {
		return new ModelAndView("cardsHomePage");
	}

	@RequestMapping("/creditcarddisplaymenu")
	public ModelAndView showCardsMenu(@RequestParam("creditCards") BigInteger creditCard) {
		this.cardNumber = creditCard;
		try {
			creditBean = creditService.fetchCreditdetails(creditCard);
		} catch (IBSException e) {
		}
		return new ModelAndView("cardsDetailsPage", "db", creditBean);
	}
	
	@RequestMapping("/cardMainMenu")
	public String showMenu() {
		return "cardsMenuPage";
	}
	
	@RequestMapping("/cardSubMenu")
	public String showCardMenu() {
		return "cardsSubMenuPage";
	}

	@RequestMapping(value = "/creditblock", method = RequestMethod.GET)
	public ModelAndView block() {
		String output = "";
		creditCard = this.cardNumber;
		try {
			if(!creditService.getCreditcardStatus(creditCard).equalsIgnoreCase("Blocked")){
			creditService.requestCreditCardLost(creditCard);
			output = " Your card has been  Blocked.Contact branch for further process";
			}
			else{
				output="Your card is already blocked.";
			}
			return new ModelAndView("outputPage","output",output);
		} catch (IBSException e) {
			output = e.getMessage();
			return new ModelAndView("errorPage","output",output);
		}
	}

	@RequestMapping(value = "/creditactivate", method = RequestMethod.GET)
	public ModelAndView activate() {
		String output = "";
		try{
		if(creditService.getCreditcardStatus(creditCard).equalsIgnoreCase("Inactive")){
			return new ModelAndView("activateCardPage");
	}
	
	else{
		output="Can not be activated";
		return new ModelAndView("outputPage", "output", output);
	}
		}catch (IBSException e) {
			output = e.getMessage();
			return new ModelAndView("errorPage", "output", output);
		}	
	}

	@RequestMapping(value = "/creditactivate", method = RequestMethod.POST)
	public ModelAndView activate(@RequestParam("pin") String pin) {
		String output = "";
		creditCard = this.cardNumber;
		try {
			
			if (creditVerify.verifyCreditPin(pin, creditCard)) {
				creditService.activateCreditCard(creditCard);
				output = "Card successfully activated!";
			} else {
				output = "Incorrect Pin entered";
			}
			return new ModelAndView("outputPage", "output", output);
		} catch (IBSException e) {
			output = e.getMessage();
			return new ModelAndView("errorPage", "output", output);
		}
	}
		
	@RequestMapping(value = "/creditdeactivate", method = RequestMethod.GET)
	public ModelAndView deactivate() {
		String output = "";
		try{
		if(creditService.getCreditcardStatus(creditCard).equalsIgnoreCase("Active")){
			return new ModelAndView("deactivateCardPage");
	}
	
	else{
		output="Can not be deactivated";
		return new ModelAndView("outputPage", "output", output);
	}
		}catch (IBSException e) {
			output = e.getMessage();
			return new ModelAndView("errorPage", "output", output);
		}	
	}
	
	@RequestMapping(value = "/creditdeactivate", method = RequestMethod.POST)
	public ModelAndView deactivate(@RequestParam("pin") String pin) {
		String output = "";
		creditCard = this.cardNumber;
		try {
			
			if (creditVerify.verifyCreditPin(pin, creditCard)) {

				creditService.deactivateCreditCard(creditCard);
				output = "Card successfully deactivated!";
			} else {
				output = "Incorrect Pin entered";
			}
			return new ModelAndView("outputPage", "output", output);
		} catch (IBSException e) {
			output = e.getMessage();
			return new ModelAndView("errorPage", "output", output);
		}
	}

	@RequestMapping(value = "/creditreset", method = RequestMethod.GET)
	public ModelAndView resetPin() {
		String output = "";
		try{
			if(!creditService.getCreditcardStatus(creditCard).equalsIgnoreCase("Blocked") && !creditService.getCreditcardStatus(creditCard).equalsIgnoreCase("Inactive") ){
			return new ModelAndView("resetCreditPinPage");
	}
	
	else{
		output="You can not change pin of a blocked/inactive card";
		return new ModelAndView("outputPage", "output", output);
	}
		}catch (IBSException e) {
			output = e.getMessage();
			return new ModelAndView("errorPage", "output", output);
		}	
	}
	@RequestMapping(value = "/creditreset", method = RequestMethod.POST)
	public ModelAndView resetPin(@RequestParam("pin") String pin) {
		String output = "";
		creditCard = this.cardNumber;
		try {
			
			if (creditVerify.verifyCreditPin(pin, creditCard)) {
				return new ModelAndView("NewDebitPinPage");
			} else {
				output = "Incorrect Pin entered";
				return new ModelAndView("outputPage", "output", output);
			}
		} catch (IBSException e) {
			output = e.getMessage();
			return new ModelAndView("errorPage", "output", output);
		}
	}
	@RequestMapping(value = "/creditresetpin", method = RequestMethod.POST)
	public ModelAndView resetPin2(@RequestParam("newpin") String newpin, @RequestParam("newpin2") String newpin2) {
		String output = "";
		creditCard = this.cardNumber;
		try {
			if (newpin2.equals(newpin)) {
				creditService.resetCreditPin(creditCard, newpin);
				output = "PIN SUCCESSFULLY CHANGED";
			} else {
				output = "PINS DO NOT MATCH...TRY AGAIN";
			}
			return new ModelAndView("outputPage", "output", output);
		} catch (IBSException e) {
			output = e.getMessage();
			return new ModelAndView("errorPage", "output", output);
		}
	}

	@RequestMapping(value = "/creditupgrade", method = RequestMethod.GET)
	public ModelAndView upgradeDebitCard() {
		String output = "";
		String type = null;
		creditCard = this.cardNumber;
		try {
			if(!creditService.getCreditcardStatus(creditCard).equalsIgnoreCase("Blocked") && !creditService.getCreditcardStatus(creditCard).equalsIgnoreCase("Inactive")){
			type = creditService.getCreditcardType(creditCard);
			if (type.equalsIgnoreCase("Silver")) {
				return new ModelAndView("upgradecreditSilver");
			} else if (type.equalsIgnoreCase("Gold")) {
				return new ModelAndView("upgradecreditGold");
			} else {
				output = "You already have a Platinum card.Can not upgrade further";
				return new ModelAndView("outputPage", "output", output);
			}}
			else{
				output="You can not upgrade a blocked/inactive card";
				return new ModelAndView("outputPage", "output", output);
			}
		} catch (IBSException e) {
			output = e.getMessage();
			return new ModelAndView("errorPage", "output", output);
		}

	}
	@RequestMapping(value = "/creditupgradeTwo", method = RequestMethod.POST)
	public ModelAndView upgradeFromSilver(@RequestParam("type") String type, @RequestParam("remarks") String remarks) {
		String output = "";
		creditCard = this.cardNumber;
		try {
			String num = creditService.requestCreditCardUpgrade(creditCard, type, remarks);
			output = "Ticket Raised successfully. Your reference Id is" + num;
			return new ModelAndView("outputPage", "output", output);
		} catch (IBSException e) {
			output = e.getMessage();
			return new ModelAndView("errorPage", "output", output);
		}
	}
	@RequestMapping(value = "/creditupgradePlat", method = RequestMethod.POST)
	public ModelAndView upgradeFromGold(@RequestParam("type") String type, @RequestParam("remarks") String remarks) {
		String output = "";
		creditCard = this.cardNumber;
		try {
			String num = creditService.requestCreditCardUpgrade(creditCard, type, remarks);
			output = "Ticket Raised successfully. Your reference Id is" + num;
			return new ModelAndView("outputPage", "output", output);
		} catch (IBSException e) {
			output = e.getMessage();
			return new ModelAndView("errorPage", "output", output);
		}
	}

	@RequestMapping(value = "/creditrequestStat", method = RequestMethod.GET)
	public String requestCardStatement() {
		return "statementCreditPage";
	}
	@RequestMapping(value = "/creditrequestStat", method = RequestMethod.POST)
	public ModelAndView requestStatement( String fromdate,String enddate) {
		creditCard = this.cardNumber;
		DateTimeFormatter formatter = DateTimeFormatter.ISO_DATE;

		try {
			if (creditService.getCreditTransactions(creditCard)) {
				LocalDate startDate1 = LocalDate.parse(fromdate, formatter);
				LocalDate endDate1 = LocalDate.parse(enddate, formatter);
				trans = creditService.getCreditTrans(startDate1, endDate1, creditCard);
			}
			return new ModelAndView("outputPage", "trans", trans);
		} catch (IBSException e) {
			String output = e.getMessage();
			return new ModelAndView("errorPage", "output", output);
		}
	}
	}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

