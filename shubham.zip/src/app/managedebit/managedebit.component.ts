import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-managedebit',
  templateUrl: './managedebit.component.html',
  styleUrls: ['./managedebit.component.css']
})
export class ManagedebitComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
