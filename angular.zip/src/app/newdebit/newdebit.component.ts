import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-newdebit',
  templateUrl: './newdebit.component.html',
  styleUrls: ['./newdebit.component.css']
})
export class NewdebitComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
