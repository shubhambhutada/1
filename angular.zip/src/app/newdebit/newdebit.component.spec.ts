import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewdebitComponent } from './newdebit.component';

describe('NewdebitComponent', () => {
  let component: NewdebitComponent;
  let fixture: ComponentFixture<NewdebitComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewdebitComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewdebitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
