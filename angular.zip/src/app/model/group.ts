export class Group {
    public groupId:number;
    public groupName:string;
    public description:string;
    public isEditing:boolean=false;
}
