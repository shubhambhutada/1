import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagecreditComponent } from './managecredit.component';

describe('ManagecreditComponent', () => {
  let component: ManagecreditComponent;
  let fixture: ComponentFixture<ManagecreditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManagecreditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagecreditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
