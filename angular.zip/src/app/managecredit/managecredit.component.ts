import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-managecredit',
  templateUrl: './managecredit.component.html',
  styleUrls: ['./managecredit.component.css']
})
export class ManagecreditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
